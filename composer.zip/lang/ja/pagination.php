<?php

return [

    /* メッセージの内容がご自身のアプリに適さない場合には、必要に応じて修正願います */

    'previous' => '&laquo; 前',
    'next' => '次 &raquo;',

];
