<?php if($message): ?>
<div class="p-4 m-2 rounded bg-green-100">
    <?php echo e($message); ?>

</div>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/components/message.blade.php ENDPATH**/ ?>